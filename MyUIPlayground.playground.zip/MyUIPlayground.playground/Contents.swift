//: Playground - noun: a place where people can play

import UIKit

var DynamicView = UIView(frame: CGRectMake(100, 200,100,100))
DynamicView.layer.cornerRadius=100
DynamicView.layer.borderWidth=2
DynamicView.backgroundColor=UIColor.greenColor()


var CrazyView =  UIView(frame: CGRectMake(300,100,100,500))
CrazyView.layer.cornerRadius=100
CrazyView.backgroundColor=UIColor.blueColor()

var CoolView = UIView(frame: CGRectMake (20,40,100,60))
CoolView.layer.cornerRadius=100
CoolView.layer.borderWidth=200
CoolView.backgroundColor=UIColor.cyanColor()

let currentDate = NSDate()
let date = UIDatePicker()
date.datePickerMode = UIDatePickerMode.Date
date.backgroundColor = UIColor.cyanColor()